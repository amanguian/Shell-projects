#include<stdio.h>



/*
Program to implement a text cipher
***************************************************************
* Author Dept . Date Notes
***************************************************************
* Alexandre D Comp. Science. Mar 15  2021 Created the script.
* Alexandre D Comp. Science  Mar 16 2021 Error handling .
* Alexandre D Comp. Science  Mar 17 2021 Start decypting .
* * Alexandre D Comp. Science  Mar 18 2021 Handling bugs + start tester.
* * Alexandre D Comp. Science  Mar 19 2021 Fnish tester + add comments .
*/




int main(int argc,char* argv[]){


//error if there is a wrong number of arguments

if(argc != 4){
	printf("Usage : %s [-e|-d] <key> <MESSAGE>\n", argv[0]);
	return 1;
}		






//error if the first argument is not valid
//argv[1] is the first argument passed to the program

char* option=argv[1];
char dash = argv[1][0];
char options = argv[1][1];

//we know that if the option is not a string of length 2 then it's wrong
int q=0;
while(option[q] != '\0'){
	q++;
}


if ( q > 2){
	printf("Error %s is not a valid option\n", argv[1]);
        return 1;
}


if (dash != '-'){
	printf("Error %s is not a valid option\n", argv[1]);
	return 1;
}

if (options != 'd' && options != 'e'){
	printf("Error %s is not a valid option\n", argv[1]);
        return 1;
}
//Now we checked that the first argument is correct

if (dash == '-' && options == 'd'){
        return 0;
}	


//error if the second argument is not valid
//we have to check that the key only contains numbers 
//a key can only have a maximum of two digits since the biggest is 10
// let's put the key in a string


char* key_string = argv[2];

int p=0;
while(key_string[p] != '\0'){
        p++;
}

int digits = p;

if (digits>2){
        printf("Error %s is not a valid key\n", key_string); // since the maximum of digits is 2 for 10
        return 1;
}



digits = argv[2][0]-'0'; //we stored the first digit

//We check if the first digit is a correct digit


if (digits<2 || digits>10){
	 printf("Error %s is not a valid key\n", key_string);
         return 1;
}



//Now we check if it has another correct digit

if(argv[2][1] != '\0'){ // if this is true then the key has 2 digits

	if (argv[2][0] == '1' && argv[2][1] == '0'){
		digits = 10;
	}
	else{
		printf("Error %s is not a valid key\n", key_string); //since it cannot be someting else than 10 of it has two digits
                        return 1;
}
}






//Let's write the code for the encryption

// Let's compute the length of the message to encrypt
char *message = argv[3];

int l=0;
while (message[l] != '\0'){
	l++;
}

if (l == 0){ //if this is true then the message is empty
	printf("\n");
	return 0;
}



//Now the message to encrypt is of length l



//Let's suppose that the key is 
int key = digits;


for (int j=0; j<key; j++){ //we are gonna define which letter of the message to print with respect to  their levels
	int index = j;
	int up_or_down = 1;

	while (index < l){

		//we print the first character of each start of line, 
		putchar(message[index]);


		if (j == key-1 || j ==0){//so that we can print the letters on the first and last level
			index += (key-1)*2;
		}
		else{ 
			if (up_or_down == 1){
				up_or_down =0; //if it's 0 then it's going down the diagonal and if it's 1 it's going up in the diagonal
				index += (key-j-1)*2;
			}
			else{ 
				up_or_down =1;
				index += j*2;

			}

		}



	}}
//Now that it's decrypted we just have to pritnt a new line
printf("\n");


return 0;
}

