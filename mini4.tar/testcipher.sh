#!/bin/bash






#checks if cipher.c exists
if [[ -f cipher.c ]] 
then
	gcc -o cipher cipher.c

else
	echo "cipher.c does not exist"
	exit 1
fi

#checks if cipher exists
if [[ ! -f cipher ]]
then
	echo "cipher does not exist"
        exit 1
fi


#Now let's try the test of the given examples

echo "Test case 1"
echo "$ ./cipher"
./cipher
printf "$ \$?\n$?\n" #it prints the output of the last command then a new line character and the the error
echo "$"
echo "----------------------------"






echo "Test case 2"
echo "$ ./cipher -k 5 HELLOTHERE"
./cipher -k 5 HELLOTHERE
printf "$ \$?\n$?\n"
echo "$"
echo "----------------------------"



echo "Test case 3"
echo "$ ./cipher -e 4.r HELLOTHERE"
./cipher -e 4.r HELLOTHERE
printf "$ \$?\n$?\n"
echo "$"
echo "----------------------------"



echo "Test case 4"
echo "$ ./cipher -e 3 THISISASECRETMESSAGE"
./cipher -e 3 THISISASECRETMESSAGE
printf "$ \$?\n$?\n"
echo "$"
echo "----------------------------"


echo "Test case 5"
echo "$ ./cipher -e 3 '""' "
./cipher -e 3 ""
printf "$ \$?\n$?\n"
echo "$"
echo "----------------------------"



echo "Test case 6"
echo "$ ./cipher -d 3 TIETSHSSSCEMSAEIAREG"
./cipher -d 3 TIETSHSSSCEMSAEIAREG
printf "$ \$?\n$?\n"
echo "$"
echo "----------------------------"






