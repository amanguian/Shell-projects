#!/bin/bash



if [[ $# -ne 1 ]]
then 
	echo "Usage ./dataformatter.sh sensorlogdir"
	exit 1

elif [[ ! -d $1 ]]
then
	
	echo -e "Error! $1 is not a valid directory name" >/dev/stderr 
	#to send the message to the standard error
	exit 1

else
	#now we iterate through all the files that we want
	for file in $(find $1 -type f -name 'sensordata-*.log')
	do
		echo -e "Processing sensor data set for $file"
		


		#with the grep command we choose which lines we want to work on
		#with the sed command we separate the date and time so that we can choose which information(year, month etc)  we use
		grep "sensor readout" $file | sed -e 's/-/ /' -e 's/-/ /' -e 's/:/ /' -e 's/:/ /' | 
		
		awk 'BEGIN {OFS=","; print "Year,Month,Hour,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5";s1="";s2="";s3="";s4="";s5=""}
	       	
		
		{ cs1=$9; cs2=$10; cs3=$11; cs4=$12; cs5=$13 }
		
		{ if (cs1=="ERROR") { cs1=s1 } }
		{ if (cs2=="ERROR") { cs2=s2 } }
		{ if (cs3=="ERROR") { cs3=s3 } }
		{ if (cs4=="ERROR") { cs4=s4 } }
		{ if (cs5=="ERROR") { cs5=s5 } }



		{s1=cs1; s2=cs2; s3=cs3; s4=cs4; s5=cs5}

		{print $1,$2,$3,$4,cs1,cs2,cs3,cs4,cs5}
		
		

		'
		#in the previous command we store the previous values in the s variables so that if the cs variables are errors we can use the s one
			
		echo "===================================="	
		echo -e "Readout statistics"

		#same reasonning with the previous grep and sed commands
		#in the following commands we're first gonna make sure that max and min have a value stored in them then we are gonna compare
		#them to the values of the sensors and make changes accordingly
		grep "sensor readout" $file | sed -e 's/-/ /' -e 's/-/ /' -e 's/:/ /' -e 's/:/ /' |

		
		awk 'BEGIN {OFS=","; print "Year,Month,Hour,MaxTemp,MaxSensor,MinTemp,MinSensor" ; Max="";Min="";MaxSensor="";MinSensor=""}

		{sensor1=$9; sensor2=$10; sensor3=$11; sensor4=$12; sensor5=$13}
		
		
		{if (sensor1!="ERROR") {Max=sensor1; MaxSensor="Sensor1"}
		else if (sensor2!="ERROR") {Max=sensor2; MaxSensor="Sensor2"}
		else if (sensor3!="ERROR") {Max=sensor3; MaxSensor="Sensor3"}
		else if (sensor4!="ERROR") {Max=sensor4; MaxSensor="Sensor4"}
		else if (sensor5!="ERROR") {Max=sensor5; MaxSensor="Sensor5"}}


		{if (sensor1!="ERROR") {Min=sensor1; MinSensor="Sensor1"}
		else if (sensor2!="ERROR") {Min=sensor2; MinSensor="Sensor2"}
		else if (sensor3!="ERROR") {Min=sensor3; MinSensor="Sensor3"}
		else if (sensor4!="ERROR") {Min=sensor4; MinSensor="Sensor4"}
		else if (sensor5!="ERROR") {Min=sensor5; MinSensor="Sensor5"}}



		{ if (sensor1!="ERROR" && sensor1 > Max) {Max=sensor1; MaxSensor="Sensor1"} }
		{ if (sensor2!="ERROR" && sensor2 > Max) {Max=sensor2; MaxSensor="Sensor2"} }
		{ if (sensor3!="ERROR" && sensor3 > Max) {Max=sensor3; MaxSensor="Sensor3"} }
		{ if (sensor4!="ERROR" && sensor4 > Max) {Max=sensor4; MaxSensor="Sensor4"} }
		{ if (sensor5!="ERROR" && sensor5 > Max) {Max=sensor5; MaxSensor="Sensor5"} }

		{ if (sensor1!="ERROR" && sensor1 < Min) {Min=sensor1; MinSensor="Sensor1"} }
		{ if (sensor2!="ERROR" && sensor2 < Min) {Min=sensor2; MinSensor="Sensor2"} }
		{ if (sensor3!="ERROR" && sensor3 < Min) {Min=sensor3; MinSensor="Sensor3"} }
		{ if (sensor4!="ERROR" && sensor4 < Min) {Min=sensor4; MinSensor="Sensor4"} }
		{ if (sensor5!="ERROR" && sensor5 < Min) {Min=sensor5; MinSensor="Sensor5"} }

				

		{ print $1,$2,$3,$4,Max,MaxSensor,Min,MinSensor}


		'
		
		echo "===================================="
			
	done
fi
	


	echo "Sensor error statistics"
	echo "Year,Month,Day,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5,Total"
	
	for file in $(find $1 -type f -name 'sensordata-*.log')
        do	

		#we are gonna sort the result of the awk so that the values are in reverse order (larger total on top) and
		#when there is an equality between totals, we are gonna compare the date in chronological order(-n)
                grep "sensor readout" $file | sed -e 's/-/ /' -e 's/-/ /' -e 's/:/ /' -e 's/:/ /' |


                awk 'BEGIN {OFS=",";Sensor1=0;Sensor2=0;Sensor3=0;Sensor4=0;Sensor5=0;Total=0}


                { if ($9=="ERROR") {Sensor1+=1} }
                { if ($10=="ERROR") {Sensor2+=1} }
                { if ($11=="ERROR") {Sensor3+=1} }
                { if ($12=="ERROR") {Sensor4+=1} }
                { if ($13=="ERROR") {Sensor5+=1} }


                {Total=Sensor1+Sensor2+Sensor3+Sensor4+Sensor5}

                END { print $1,$2,$3,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5,Total}

                ' 

	done | sort  -t "," -k 9,9rn -nk 1,3

	echo "===================================="
