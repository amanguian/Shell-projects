#ifndef zoomrecs_h
#define zoomrecs_h
#include <stdio.h>
#include <string.h>
#include <stdlib.h>




struct ZoomRecord
{
char email[60]; // email of the student
char name[60]; // name of the student
int durations[9]; // duration of each lab.
struct ZoomRecord *next;
};


//We have to do functions prototype


struct ZoomRecord *addZoomRecord(char line[200], struct ZoomRecord *first_zoom);

void generateAttendance(FILE *output_file, struct ZoomRecord *record_per_student);

#endif
