#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "zoomrecs.h"




struct ZoomRecord *addZoomRecord(char line[200],struct ZoomRecord *first_zoom){
	

	char *info;
	struct ZoomRecord *t;
	int same_mail=0;

	t=first_zoom;
	info=strtok(line, ",");//Now we have the mail of the student
	
	

	



	//Here we are going to check if we have to update the duration or create a new record
	
	
	while(t!=NULL){
		if(strcmp(t->email, info)==0){
			int i=0;
			while(i<2){
				info=strtok(NULL, ",");
				i++;
			}//Now in the info variable we carry the letter of the lab
			int lab_number=(char)*info-65;//We converted the string into an int
			info=strtok(NULL, ",");//Now we have the duration
			int duration=atoi(info);

			t->durations[lab_number] = (t->durations[lab_number])+duration;//update the duration
			same_mail=1;//So that we know that there was a match
		}
		t=t->next;
	}
	
	
	if (same_mail==0){//If we didn't find a match with the email then we have to create a record for that student

		struct ZoomRecord *new_record=NULL;
		new_record=(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));

		if (new_record==NULL){
			printf("Error memory");
			exit(1);
		}
		//We are going to add the infos of the record
		strcpy(first_zoom->email, info);//The mail in the record
		info=strtok(NULL, ",");
		strcpy(first_zoom->name, info);//the name in the record
		info=strtok(NULL, ",");//This is the lab

		int lab_number=(char)*info-65;//Same reasoning as in the while loop

		for (int lab=0; lab<9; lab++){
			int duration;
			info=strtok(NULL, ",");//This is the duration of the lab
			
			
			if(lab==lab_number){
				duration=atoi(info);
				new_record->durations[lab]=duration;
			}
			else{
				new_record->durations[lab]=0;
			}
		}
		//Now we have to place the record in the linked list
		
		if(first_zoom==NULL){
			first_zoom=new_record;
			new_record->next=NULL;
			
		}
		else{
			//We are going to use two variables to traverse the linked list to determine where to input the record in alphabetical order
			struct ZoomRecord *prev_new_rec=first_zoom;
			struct ZoomRecord *aft_new_rec=NULL;
			
			//We compare the two mail for the alphabetical order
			while(prev_new_rec!=NULL && strcmp(prev_new_rec->email, new_record->email)>0){
				aft_new_rec=prev_new_rec;
				prev_new_rec=prev_new_rec->next;
			}
			aft_new_rec->next=new_record;
			new_record->next=prev_new_rec;
		
		}
		free(new_record);
	}
	
	return first_zoom;}//We return the head of the linked list so that we can acces in labapp
	






void generateAttendance(FILE *output_file, struct ZoomRecord *record_per_student){
	struct ZoomRecord *t;

	if (record_per_student==NULL){//then there is no linked list
		printf("No records");
	}

	else{
		t=record_per_student;

		fprintf(output_file,"User Email,Name (Original Name),A,B,C,D,E,F,G,H,I,Attendance (Percentage)\n");
		//Now we printed the header in the output file
		//Therefore we are going to print all the info of the records(nodes) of the students
		
		while(t!=NULL){
			fprintf(output_file,"%s,", t->email);//we printed the email
            		fprintf(output_file,"%s,", t->name);//We printed the name of the student

			for (int i=0; i<9; i++){
				fprintf(output_file, "%d,", t->durations[i]);
			}
			
			//Now we are going to compute the average attendance, for that we are going to check whether
			//the duration of the lab is at least 45 minutes, if not we will not count it
			
			float attendance=0;
			for (int j=0; j<9; j++){
				if (t->durations[j] >= 45){
					attendance++;
				}}
			attendance=attendance/9;

			fprintf(output_file,"%0.2f\n", attendance);//0.2 bcs we want decimal points of attendance percentages to two places

			t=t->next;
		}}};









		






