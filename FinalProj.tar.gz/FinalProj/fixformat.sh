#/bin/bash

#To check the input

if [[ $# != 2 ]] 
then
	echo "Usage fixformat.sh <dirname> <opfile>"
	exit 1
#To check the directory
elif [[ ! -d $1 ]]
then
	echo -e "Error $1 is not a valid directory"
	exit 1



fi
	



echo "User Email,Name (Original Name),Lab,Total Duration (Minutes)" > $2

#this is where find all the files to modify 
for file in $(find $1 -type f -iname 'lab-[a-e].csv')
do

	#to grab the lab letter in the file
	lab_letter=${file: -5:-4}

	#to put the lab letter in upper case
	upper_letter=${lab_letter^}
	
	#each line we are going to input the fields into their corresponding variables and print them to the output file
	grep '@mail.mcgill.ca' $file | awk -v upper_letter="$upper_letter" 'BEGIN {OFS=","; FS=","; name=""; user_email=""; total_duration=0}
	{
		if (NF==4) {name=$1;user_email=$2;total_duration=$3}
		if (NF==6) {name=$1;user_email=$2;total_duration=$5}
		print user_email,name,upper_letter,total_duration
		
	}' >> $2

done





