#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "zoomrecs.h"



int main(int argc, char *argv[]){

	FILE *input_file = fopen(argv[1], "rt");

	
	struct ZoomRecord *first_zoom = NULL;
	
	//first_zoom will be the head of our linked list
		
	first_zoom =(struct ZoomRecord*)malloc(sizeof(struct ZoomRecord));
	
	
	//We are going to open again the output file in write mode
	FILE *output_file = fopen(argv[2], "wt");
	

	char line[200];
	
	//We traverse the whole file to update any record
	while(fgets(line,sizeof(line), input_file)){
		first_zoom = addZoomRecord(line, first_zoom);
	}


	generateAttendance(output_file, first_zoom);
	fclose(input_file);
	fclose(output_file);
	free(first_zoom);
}
