#!/bin/bash


#first, we have to write the first tag for the start of the file

echo -e "<TABLE>">$2

#Then for each line, we are going to add <TR> and <TD>  at the beggining and </TD></TR> at the end
#and we are going to enclose the between <TD> and </TD> tags, let's do that with sed:


for line in $1
do
	sed -e 's|^|<TR><TD>|' -e 's|,|</TD><TD>|g' -e 's|$|</TD></TR>|' $line >>$2
done

#print the last tag
echo -e "</TABLE>" >>$2

