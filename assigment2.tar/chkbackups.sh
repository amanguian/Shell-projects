#!/bin/bash



if [[ $# -eq 2 || $# -eq 1 ]]
then

	if [[ $# -eq 1 ]]
	then
		#so that we get the same variable whether or not there is a second input
		sourcedir="$(pwd)"
	else
		sourcedir=$2
	fi
	#let's check if there are mistakes
	if [[ ! -d $1 ]]
	then
		echo -e "Error!! $1 is not a valid directory"
		exit 1

	elif [[ ! -d $sourcedir ]]
	then
		echo -e "Error!! $sourcedir is not a valid directory"
		exit 1

	elif [[ ! "$(ls $sourcedir)" ]]
	then
		echo -e "Error!! $sourcedir) has no files"
		exit 1
	fi
	#end mistakes check


	#let's check if all the files in the source directory are backed up
	x=0
	for i in $(ls $sourcedir)
	do 
		name=$(basename $i)
		if [[ -f "$1/$name.$(date +"%Y%m%d")" ]]
		then
		       continue
	      	else
			echo -e "$name does not have a backup for today"
			x=1
		fi	
	done
	
	#if x!=1 that means that all files have been backed up
	if [[ $x -ne 1 ]]
	then 
		if [[ $# -eq 1 ]]
		then
			#in the tester when there is the default current dir it prints a . 
			echo -e "All files in . have backups for today in $1" 
		else
			echo -e "All files in $sourcedir  have backups for today in $1"

		fi
	fi
	
	exit 0


else
	echo -e "Usage: ./chkbackups.sh backupdirname [sourcedir]"
        exit 1


fi
