#!/bin/bash




#we create the condition
if [[ $# -ne 2 ]]
then
        echo -e "Usage: $0 backupdirname filetobackup"
        exit 1

fi

if [[ ! -d "$1" ]]
then
        echo -e "Error!! $1 is not a valid directory"
        exit 1

fi

#If the file name passed to the script is not valid
if [[ ! -f "$2" ]]
then
     echo -e "Error!! $2 is not a valid file"
     exit 1
fi



#we put in a variable name the basename of $2
name=$(basename $2)


#Now we can check if it has already been backed up checking the date
if [[ -f $1/$name.$(date +"%Y%m%d") ]]
then
	
	echo -e "Backup file already exists for $(date +"%Y%m%d")"
	exit 1

#if the first statement doesn't work it means that the file doesn't exist therefore we have to copy it
else 
	cp $2 $1/$name.$(date +"%Y%m%d")
fi


exit 0
